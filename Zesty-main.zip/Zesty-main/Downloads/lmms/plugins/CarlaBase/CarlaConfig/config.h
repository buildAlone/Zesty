// config.h for Carla
#ifndef FOR_CARLA_CONFIG_H
#define FOR_CARLA_CONFIG_H

#ifdef _MSC_VER
#define HAVE_CPP11_SUPPORT 1
#endif

#endif
